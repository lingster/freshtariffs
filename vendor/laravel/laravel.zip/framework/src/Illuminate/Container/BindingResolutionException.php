<?php namespace Illuminate\Container;

class BindingResolutionException extends \Exception {}
