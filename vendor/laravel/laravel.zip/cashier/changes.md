# Cashier Change Log

## Version 2.0.3

- Added space for extra / VAT information in receipts.
- Implemented missing method on web hook controller.

## Version 2.0.2

- Fixed how credit cards are updated.

## Version 2.0.1

- Renamed WebhookController's failed payment method to handleInvoicePaymentFailed.
- Added ability to webhook controller to automatically route all webhooks to appropriately named methods of they area available.
